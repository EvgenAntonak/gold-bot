import telebot
from telebot import types
import os

TOKEN = os.environ.get("TOKEN")  # Або встав токен напряму: TOKEN = "123:ABC"
ADMIN_ID = 5244917444  # Замінити на свій Telegram ID

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "Вітаю! Надішліть кількість голди (мінімум 50).")

@bot.message_handler(func=lambda message: message.text.isdigit())
def handle_order(message):
    gold_amount = int(message.text)
    if gold_amount < 50:
        bot.send_message(message.chat.id, "Мінімальне замовлення — 50 голди.")
        return
    price = round((gold_amount / 100) * 32, 2)
    msg = (
        f"💰 Ви замовили {gold_amount} голди.
"
        f"Ціна: {price} грн

"
        "📸 Надішліть, будь ласка, квитанцію про оплату (фото або скріншот)."
    )
    bot.send_message(message.chat.id, msg)
    bot.register_next_step_handler(message, handle_receipt, gold_amount, price)

def handle_receipt(message, gold_amount, price):
    if message.photo or message.document:
        bot.forward_message(ADMIN_ID, message.chat.id, message.message_id)
        bot.send_message(message.chat.id, "✅ Квитанцію надіслано адміністратору. Очікуйте підтвердження.")
        bot.send_message(ADMIN_ID, f"Нове замовлення:
{gold_amount} голди — {price} грн
Від @{message.from_user.username or message.from_user.first_name}")
    else:
        bot.send_message(message.chat.id, "⚠ Будь ласка, надішліть фото або скріншот квитанції.")
        bot.register_next_step_handler(message, handle_receipt, gold_amount, price)

bot.polling()